// Page transition: fade-out on internal link click
document.addEventListener('click', (e)=>{
  const a = e.target.closest('a');
  if(!a) return;
  const url = new URL(a.href, location.href);
  const isInternal = url.origin === location.origin;
  const isHash = url.hash && url.pathname === location.pathname;
  if(isInternal && !isHash && !a.hasAttribute('target')){
    e.preventDefault();
    document.body.classList.add('out');
    setTimeout(()=> location.href = a.href, 220);
  }
});

// When page loads, mark ready for reveal animations
window.addEventListener('DOMContentLoaded', ()=>{
  document.querySelector('.page')?.classList.add('ready');
});

// Dropdown toggle (keyboard accessibility)
document.querySelectorAll('.dropdown > button').forEach(btn=>{
  btn.addEventListener('keydown', (e)=>{
    if(e.key === 'Escape'){ btn.blur(); }
  });
});